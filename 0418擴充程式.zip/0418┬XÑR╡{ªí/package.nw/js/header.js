var filepath = { media: 'media/', msg_zh:"msg/js/zh-hant.js", msg_en: "msg/js/en.js"};
